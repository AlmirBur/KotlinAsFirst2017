Lorem ipsum *dolor sit amet*, consectetur **adipiscing** elit.
Vestibulum lobortis. ~~Est vehicula rutrum *suscipit*~~, ipsum ~~lib~~ero *placerat **tortor***.

Suspendisse ~~et elit in enim tempus iaculis~~.
